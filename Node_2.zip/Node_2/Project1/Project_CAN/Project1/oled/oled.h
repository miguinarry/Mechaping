/*
 * oled.h
 *
 * Created: 20.09.2016 15:17:35
 *  Author: simonep
 */ 


#ifndef OLED_H_
#define OLED_H_

void oled_init();
void oled_write_d(char data);
void write_c(char com);
void oled_reset();
void oled_pos(int line, int coloumn);
void oled_write_char(char val);
void oled_goto_line( uint8_t line);
void oled_goto_column( int coloumnOLED_H_);


int oled_write_char_stream(char val, FILE* stream);

static FILE oled_stream = FDEV_SETUP_STREAM(oled_write_char_stream, NULL, _FDEV_SETUP_WRITE);

#define FILE_STREAM		&oled_stream



#endif /* ); */