/*
 * Menu.c
 *
 * Created: 04.10.2016 11:41:10
 *  Author: simonep
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include "Menu.h"
#include "oled.h"



 
ITEM* menu_setup( void ){
	 
	ITEM *see_highscore=(ITEM*) malloc (sizeof(ITEM));
	ITEM *reset_highscore=(ITEM*) malloc (sizeof(ITEM));

	ITEM *main_menu=(ITEM*) malloc (sizeof(ITEM));
	ITEM *calibration=(ITEM*) malloc(sizeof(ITEM));
	ITEM *new_game=(ITEM*) malloc(sizeof(ITEM));
	ITEM *high_score=(ITEM*) malloc (sizeof(ITEM));
	ITEM *difficulty=(ITEM*) malloc(sizeof(ITEM));
	ITEM *objective=(ITEM*) malloc (sizeof(ITEM));
	
	
	// main menu page initialization
	main_menu->text[0] = "> New Game";
	main_menu->text[1] = "  High Score";
	main_menu->text[2] = "  Difficulty";
	main_menu->text[3] = "  Objective";
	main_menu->text[4] = "  Calibration";

	
	
    main_menu->parent = NULL;
    main_menu->children[0] = new_game;
    main_menu->children[1] = high_score;
    main_menu->children[2] = difficulty;
    main_menu->children[3] = objective;
    main_menu->children[4] = calibration;
	
	// New Game page initialization
	new_game->text[0] = "> new game";
	new_game->text[1] = "  ";
	new_game->text[2] = "  ";
	new_game->text[3] = "  ";
	new_game->text[4] = "  ";

	
	
	new_game->parent = main_menu;
	new_game->children[0] = NULL;
	new_game->children[1] = NULL;
	new_game->children[2] = NULL;
	new_game->children[3] = NULL;
	new_game->children[4] = NULL;
	
	// High Score page initialization
	high_score->text[0] = "> See Highscore";
	high_score->text[1] = "  Reset Highscore";
	high_score->text[2] = "  ";
	high_score->text[3] = "  ";
	high_score->text[4] = "  ";

	
	high_score->parent = main_menu;
	high_score->children[0] = see_highscore;
	high_score->children[1] = reset_highscore;
	high_score->children[2] = NULL;
	high_score->children[3] = NULL;
	high_score->children[4] = NULL;
	
	// Objective page initialization
	objective->text[0] = "> Objective";
	objective->text[1] = "  ";
	objective->text[2] = "  ";
	objective->text[3] = "  ";
	objective->text[4] = "  ";

	
	objective->parent = main_menu;
	objective->children[0] = NULL;
	objective->children[1] = NULL;
	objective->children[2] = NULL;
	objective->children[3] = NULL;
	objective->children[4] = NULL;
	
	// Difficulty page initialization
	difficulty->text[0] = "> Easy";
	difficulty->text[1] = "  Medium";
	difficulty->text[2] = "  Hard";
	difficulty->text[3] = "  NTNU";
	difficulty->text[4] = "  ";

	
	difficulty->parent = main_menu;
	difficulty->children[0] = NULL;
	difficulty->children[1] = NULL;
	difficulty->children[2] = NULL;
	difficulty->children[3] = NULL;
	difficulty->children[4] = NULL;
	
	// Calibration page initialization
	calibration->text[0] = "> calibration";
	calibration->text[1] = "  ";
	calibration->text[2] = "  ";
	calibration->text[3] = "  ";
	calibration->text[4] = "  ";

	
	calibration->parent = main_menu;
	calibration->children[0] = NULL;
	calibration->children[1] = NULL;
	calibration->children[2] = NULL;
	calibration->children[3] = NULL;
	calibration->children[4] = NULL;
	
	// See Higscore page initialization
	see_highscore->text[0] = "> see highscore";
	see_highscore->text[1] = "  ";
	see_highscore->text[2] = "  ";
	see_highscore->text[3] = "  ";
	see_highscore->text[4] = "  ";

	
	see_highscore->parent = high_score;
	see_highscore->children[0] = NULL;
	see_highscore->children[1] = NULL;
	see_highscore->children[2] = NULL;
	see_highscore->children[3] = NULL;
	see_highscore->children[4] = NULL;
	
	// Reset Higscore page initialization
	reset_highscore->text[0] = "> reset highscore";
	reset_highscore->text[1] = "            ";
	reset_highscore->text[2] = "          ";
	reset_highscore->text[3] = "         ";
	reset_highscore->text[4] = "         ";

   
   reset_highscore->parent = high_score;
   reset_highscore->children[0] = NULL;
   reset_highscore->children[1] = NULL;
   reset_highscore->children[2] = NULL;
   reset_highscore->children[3] = NULL;
   reset_highscore->children[4] = NULL;
   
	 
	 return main_menu;
}
 
void print_menu( ITEM * menuScreen)
{
	oled_reset();
	for ( uint8_t i = 0 ; i < 5 ; i++ )
	{
		oled_goto_line(i+1);
		write_c(0x00);
		write_c(0x10);
		fprintf(FILE_STREAM, menuScreen->text[i]);
	}
	
}
void arrow_up(uint8_t line_arrow)
{
	oled_goto_line( line_arrow+2);
	write_c(0x00);
	write_c(0x10);
	fprintf(FILE_STREAM,"  ");
	
	oled_goto_line( line_arrow+1);
	write_c(0x00);
	write_c(0x10);
	fprintf(FILE_STREAM,"> ");
}

void arrow_down(uint8_t line_arrow)
{
	oled_goto_line( line_arrow);
	write_c(0x00);
	write_c(0x10);
	fprintf(FILE_STREAM,"  ");
	
	oled_goto_line( line_arrow + 1);
	write_c(0x00);
	write_c(0x10);
	fprintf(FILE_STREAM,"> ");
}

