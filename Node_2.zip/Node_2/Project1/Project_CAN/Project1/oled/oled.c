/*
 * oled.c
 *
 * Created: 20.09.2016 15:17:23
 *  Author: simonep
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include "font.h"
#include "oled.h"

char pages[8] = {0xb0,0xb1,0xb2,0xb3,0xb4,0xb5,0xb6,0xb7};

void write_c(char com){
	volatile char *oled_c = (char *) 0x1000;
	oled_c[0]= com;
}

void oled_write_d(char data){
	volatile char *oled_d = (char *) 0x1200;
	oled_d[0]= data;
}


void oled_reset()
{
	for(int i=0;i<8;i++){
		write_c(pages[i]);
		for(int j=0;j<128;j++){
			oled_write_d(0b00000000);
		}
	}
	write_c(0xb0);
}

void oled_clear_line(int line)
{
	write_c(pages[line-1]);	
	for(int j=0;j<128;j++)
	{
		oled_write_d(0b00000000);
	}
}


void oled_goto_line( uint8_t line)
{
	write_c(pages[line-1]);
}

void oled_goto_column( int coloumn)
{
	write_c(coloumn);
	coloumn=coloumn+16;
	write_c(coloumn);
}

void oled_pos(int line, int coloumn)
{
	
	write_c(pages[line-1]);
	write_c(coloumn);
	coloumn=coloumn+16;
	write_c(coloumn);
	
}

void oled_write_char(char val)
{
	uint8_t address = (uint8_t)val - 32;
	for(int i=0;i<5;i++){
		oled_write_d(pgm_read_byte(&myfont[address][i]));
	}
}


int oled_write_char_stream(char val, FILE* stream)
{
	uint8_t address = (uint8_t)val - 32;
	for(int i=0;i<5;i++){
		oled_write_d(pgm_read_byte(&myfont[address][i]));
	}
	return 0;
}





void oled_init(){
	write_c(0xae); // display off
	write_c(0xa1); //segment remap
	write_c(0xda); //common pads hardware: alternative
	write_c(0x12);
	write_c(0xc8); //common output scan direction:com63~com0
	write_c(0xa8); //multiplex ration mode:63
	write_c(0x3f);
	write_c(0xd5); //display divide ratio/osc. freq. mode
	write_c(0x80);
	write_c(0x81); //contrast control
	write_c(0x50);
	write_c(0xd9); //set pre-charge period
	write_c(0x21);
	write_c(0x20); //Set Memory Addressing Mode
	write_c(0x02);
	write_c(0xdb); //VCOM deselect level mode
	write_c(0x30);
	write_c(0xad); //master configuration
	write_c(0x00);
	write_c(0xa4); //out follows RAM content
	write_c(0xa6); //set normal display
	write_c(0xaf); // display on
	
	write_c(0xb0);
}