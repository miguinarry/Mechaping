/*
 * MCP2515.h
 *
 * Created: 05.10.2016 12:55:08
 *  Author: simonep
 */ 


#ifndef MCP2515_H_
#define MCP2515_H_
#include <stdbool.h>

char mcp_read(char reg );
void mcp_write(char reg, char data );
void mcp_request_send(int opt);
char mcp_read_status(void );
void mcp_bit_modify(char reg, char data, char mask );
void mcp_reset(void );




#endif /* MCP2515_H_ */