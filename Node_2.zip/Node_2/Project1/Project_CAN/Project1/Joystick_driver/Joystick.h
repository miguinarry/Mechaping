/*
 * Joystick.h
 *
 * Created: 13.09.2016 17:01:46
 *  Author: simonep
 */ 


#ifndef JOYSTICK_H_
#define JOYSTICK_H_

int joystick_analog_position(uint8_t adcX /*, int adcY*/);
//int slider_position(int adcX, int adcY);


#endif /* JOYSTICK_H_ */