/*
 * node2.h
 *
 * Created: 18.10.2016 14:34:51
 *  Author: simonep
 */ 


#ifndef NODE2_H_
#define NODE2_H_

void node2_serial_Transmit( unsigned char data );
unsigned char node2_serial_Receive( void );
void node2_serial_Init( unsigned int ubrr );



#endif /* NODE2_H_ */