/*
 * ADC_Internal.h
 *
 * Created: 25.10.2016 18:29:29
 *  Author: simonep
 */ 


#ifndef ADC_INTERNAL_H_
#define ADC_INTERNAL_H_


#include <avr/io.h>

void INTADC_init(void);
uint16_t INTADC_read(void);

void goal_test(void); // TODO: MOVE TO GAME APPLICATION
uint8_t get_goals(void);




#endif /* ADC_INTERNAL_H_ */