/*
 * ADC_internal.c
 *
 * Created: 25.10.2016 18:29:43
 *  Author: simonep
 */ 
#include "ADC_Internal.h"
#include "../MCP/MCP2515.h"


static uint8_t goals1 = -1;
static uint8_t prev = 0;
static uint8_t threshold = 100;

void INTADC_init(void) {

	ADCSRA |= (1<<ADPS0)|(1<<ADPS1)|(1<<ADPS2); // Set prescaler
	
	ADMUX |= (1 << REFS0);
	 // Enable ADC
	ADCSRA |= (1 << ADEN);
}

uint16_t INTADC_read(void) {
	 // Start conversion
	ADCSRA |= (1 << ADSC);
	while(!ADCSRA & (1 << ADIF)); // Continue when conversion is finished
	return ADC & 0x03ff;
}



void goal_test(void) {
	uint16_t read_value=INTADC_read();
	if (read_value < threshold && !prev) {
		goals1 += 1;
		prev = 1;
		} else if (read_value > threshold) {
		prev = 0;
	}
}


uint8_t get_goals(void) {
	return goals1;
}
