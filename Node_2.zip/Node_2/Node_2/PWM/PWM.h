/*
 * PWM.h
 *
 * Created: 25.10.2016 12:05:53
 *  Author: simonep
 */ 


#ifndef PWM_H_
#define PWM_H_


void pwm_init(float ms);
void pwm_set_width(float ms) ;

#endif /* PWM_H_ */