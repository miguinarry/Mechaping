/*
 * uart.h
 *
 * Created: 18.10.2016 15:17:39
 *  Author: simonep
 */ 


#ifndef UART_H_
#define UART_H_


void node2_serial_Transmit( unsigned char data );
unsigned char node2_serial_Receive( void );
void node2_serial_Init( unsigned int ubrr );




#endif /* UART_H_ */