/*
 * solenoid.c
 *
 * Created: 08.11.2016 15:44:17
 *  Author: simonep
 */ 
#include "solenoid.h"

#include <util/delay.h>
#include <avr/io.h>

void solenoid_init(void) 
{
	 DDRB |= (1 << DDB4);
	 PORTB |= (1 << PB4);
}
void solenoid_ping(void) 
{
	 PORTB &= ~(1 << PB4);
 	 _delay_ms(500);
	 PORTB |= (1 << PB4);
	 _delay_ms(500);
}
