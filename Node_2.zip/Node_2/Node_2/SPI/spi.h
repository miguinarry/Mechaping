/*
 * spi.h
 *
 * Created: 18.10.2016 15:17:13
 *  Author: simonep
 */ 


#ifndef SPI_H_
#define SPI_H_

void SPI_MasterInit(void);
char SPI_MasterTransmit(char cData);
void CS_high(void);
void CS_low(void);




#endif /* SPI_H_ */