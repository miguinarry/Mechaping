/*
 * Node_2.c
 *
 * Created: 18.10.2016 15:14:59
 *  Author: simonep
 */ 

#define BAUD 9600
#define F_CPU 16000000
#define UBRRCALC F_CPU/16/BAUD-1

#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <util/delay.h>
#include "UART/uart.h"
#include "CAN/can.h"
#include "MCP/MCP2515.h"
#include "MCP/mcp.h"
#include "ADC_internal/ADC_Internal.h"
#include "PWM/PWM.h"
#include "SPI/spi.h"


int main(void)
{
	pwm_init(1.0);
	INTADC_init();
    node2_serial_Init(UBRRCALC);
	float ms;
    can_init(MODE_NORMAL);
	message_can msg_rx;
    message_can msg = {
	    .id = 1,
	    .length = 8,
	    .data[0] = 25
    };
    int8_t buffer;
    while(1){
	    
	    //can_transmit(msg);
		_delay_ms(100);
		msg_rx = can_receive();
		//printf("Data X : %i\n",msg_rx.data[0]);
		//printf("Data Y : %i\n",msg_rx.data[1]);
		
		//changing the modulation
		
		ms=0.9+1.2*((float)msg_rx.data[1]+0)/256;
		//ms = ((float)msg_rx.data[1])*(2.1-0.9) / 200 + 0.9;
		pwm_set_width(ms);
	   // buffer = CAN_transmitComplete();
	   
	   
	   goal_test();
	   //printf("ADC_ %i\t",INTADC_read());
	   printf("Goals: %i\n",get_goals());
    }
    

    return 0;

}