/*
 * Node_2.c
 *
 * Created: 18.10.2016 15:14:59
 *  Author: simonep
 */ 

#define BAUD 9600
#define F_CPU 16000000
#define UBRRCALC F_CPU/16/BAUD-1

	
#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <util/delay.h>
#include "UART/uart.h"
#include "CAN/can.h"
#include "MCP/MCP2515.h"
#include "MCP/mcp.h"
#include "ADC_internal/ADC_Internal.h"
#include "PWM/PWM.h"
#include "SPI/spi.h"
#include "Motor/Motor.h"
#include "TWI_I2C/TWI_Master.h"
#include "avr/interrupt.h"
#include "solenoid/solenoid.h"

#define addres_1  0x50

int main(void)
{
	unsigned char messageBuf[4];
	pwm_init(1.0);
	INTADC_init();
    node2_serial_Init(UBRRCALC);
	  
	float ms;
    can_init(MODE_NORMAL);
	motor_init();
	solenoid_init();

	message_can msg_rx;
    message_can msg = {
	    .id = 1,
	    .length = 8,
	    .data[0] = 25
    };
	messageBuf[0] = 0x50;     // The first byte must always consist of General Call code or the TWI slave address.
	messageBuf[1] = 0x00;             // The command or data to be included in the general call.
	messageBuf[2] = 0;
	
    printf("Starting\n");
	sei();
    while(1)
	{
		_delay_ms(120);
		msg_rx = can_receive();
		
		//changing the modulation
		
		ms=0.9+1.2*((float)msg_rx.data[1]+0)/256;
		
		pwm_set_width(ms);
	   
	   if (msg_rx.data[0]>140)
	   {
		   motor_set_direction(RIGHT);
		   motor_set_speed(0x50);
	   }
	   else if(msg_rx.data[0]<110)
	   {
		   motor_set_direction(LEFT);
		   motor_set_speed(0x50);
	   }
	   else
	   {
		   motor_set_speed(0x00);
	   }
	   
	    if (msg_rx.data[2]!=0)
		{
			solenoid_ping();
		}
	   goal_test();
	   printf("button : %d\t",msg_rx.data[2]);
	   printf("Data X : %d\t",msg_rx.data[0]);
	   printf("Data Y : %d\t",msg_rx.data[1]);
	   printf("ADC_ %i\t",INTADC_read());
	   printf("Goals: %i\n",get_goals());
	   
	   
    }
    

    return 0;

}