/*
 * Node_2.c
 *
 * Created: 18.10.2016 15:14:59
 *  Author: simonep
 */ 

#define BAUD 9600
#define F_CPU 16000000
#define UBRRCALC F_CPU/16/BAUD-1

#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <util/delay.h>
#include "UART/uart.h"
#include "CAN/can.h"
#include "MCP/MCP2515.h"


int main(void)
{
    node2_serial_Init(UBRRCALC);
    can_init(MODE_NORMAL);
	message_can msg_rx;
    message_can msg = {
	    .id = 1,
	    .length = 8,
	    .data[0] = 25
    };
    int8_t buffer;
    while(1){
	    
	    //can_transmit(msg);
		_delay_ms(100);
		msg_rx = can_receive();
		printf("Data : %i\n",msg_rx.data[0]);
	   // buffer = CAN_transmitComplete();
    }
    

    return 0;

}