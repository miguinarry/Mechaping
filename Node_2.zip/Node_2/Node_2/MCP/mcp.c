/*
 * mcp.c
 *
 * Created: 18.10.2016 15:16:53
 *  Author: simonep
 */ 
#include <avr/io.h>
#include "mcp.h"
#include "MCP2515.h"
#include "../SPI/spi.h"
#include "../UART/uart.h"


char mcp_read(char reg )
{
	char a;
	CS_low();
	SPI_MasterTransmit(MCP_READ);
	SPI_MasterTransmit(reg);
	a = SPI_MasterTransmit(0xAA);
	CS_high();
	return a;
}


void mcp_write(char reg, char data )
{
	CS_low();
	SPI_MasterTransmit(MCP_WRITE);
	SPI_MasterTransmit(reg);
	SPI_MasterTransmit(data);
	CS_high();
}
void mcp_request_send(int opt)
{
	CS_low();
	char instruction = 0b10000000;
	if (opt==0)
	{
		instruction |= 1<<0;
	}
	if (opt==1)
	{
		instruction |= 1<<1;
	}
	if (opt==2)
	{
		instruction |= 1<<2;
	}
	SPI_MasterTransmit(instruction);
	CS_high();
}
char mcp_read_status(void )
{
	char a, b;
	CS_low();
	SPI_MasterTransmit(MCP_READ_STATUS);
	a = SPI_MasterTransmit(0xAA);
	b = SPI_MasterTransmit(0xAA);
	CS_high();
	if (a==b)
	{
		return a;
	}
	else
	{
		return 0;
	}
}

void mcp_bit_modify(char reg, char mask, char data )
{
	CS_low();
	SPI_MasterTransmit(MCP_BITMOD);
	SPI_MasterTransmit(reg);
	SPI_MasterTransmit(mask);
	SPI_MasterTransmit(data);
	CS_high();
}
void mcp_reset(void )
{
	CS_low();
	SPI_MasterTransmit(MCP_RESET);
	CS_high();
}