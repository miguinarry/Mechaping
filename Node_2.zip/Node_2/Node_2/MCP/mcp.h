/*
 * mcp.h
 *
 * Created: 18.10.2016 15:17:03
 *  Author: simonep
 */ 


#ifndef MCP_H_
#define MCP_H_

char mcp_read(char reg );
void mcp_write(char reg, char data );
void mcp_request_send(int opt);
char mcp_read_status(void );
void mcp_bit_modify(char reg, char data, char mask );
void mcp_reset(void );



#endif /* MCP_H_ */