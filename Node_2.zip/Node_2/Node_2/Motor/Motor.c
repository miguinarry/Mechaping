/*
 * Motor.c
 *
 * Created: 01.11.2016 16:06:24
 *  Author: simonep
 */ 

#define F_CPU 16000000 //clock frequency in hertz
#include <util/delay.h>
#include "Motor.h"
#include "../TWI_I2C/TWI_Master.h"
#include <avr/io.h>

void motor_init(void) {
	TWI_Master_Initialise();
	 //Set DIR pin as output
	DDRH |= (1 << DDH1);
	 //Set RST pin as output
	DDRH |= (1 << DDH6);
	 //Set !OE pin as output
	DDRH |= (1 << DDH5);
	 //Set SEL pin as output
	DDRH |= (1 << DDH3);
	 //Set EN pin as output
	DDRH |= (1 << DDH4);
	 //Enable motor
	PORTH |= (1 << PH4);
	DDRK = 0;
	motor_reset_counter();
	//set_bit(DDRH, DDH5); //Disable output of encoder value

}
void motor_reset_counter(void) {
	PORTH &= ~(1 << PH6);
	_delay_ms(20);
	PORTH |= (1 << PH6);
}

int16_t motor_read_encoder(void) {
	int16_t output;
 //Set OE low
	PORTH &= ~(1 << PH5);

	PORTH &= ~(1 << PH3);
	_delay_ms(20);
	output = PINK << 8; //Read MSB

	PORTH |= (1 << PH3);
	_delay_ms(20);
	output += PINK; //Read LSB
 //Set OE high
	PORTH |= (1 << PH5);
	return output;
}
void motor_set_direction(motor_direction_t dir) {
	switch(dir) {
		case LEFT:

		PORTH &= ~(1 << PH1);
		break;
		case RIGHT:

		PORTH |= (1 << PH1);
		break;
	}
}
void motor_set_speed(char speed) {
	unsigned char msg[3];
	msg[0] = 0x50;
	msg[1] = 0x00;
	msg[2] = speed;
	if ( !TWI_Transceiver_Busy() ) {
		TWI_Start_Transceiver_With_Data(msg, 3);
	}
}
