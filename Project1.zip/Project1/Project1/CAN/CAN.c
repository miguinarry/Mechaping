/*
 * CAN.c
 *
 * Created: 11.10.2016 16:05:24
 *  Author: simonep
 */ 


#include "can.h"
#include <avr/delay.h>
#include "..//SPI/SPI.h"
char val;


uint8_t rxbuffer = 0;

void can_init(uint8_t mode)
{
	SPI_MasterInit();
	mcp_reset();
	_delay_ms(100);
	
	if((mcp_read(MCP_CANSTAT)& MODE_MASK) != MODE_CONFIG) {
		printf("MCP2515 is NOT in configuration mode after reset!\n");
	}
	
	
	mcp_bit_modify(MCP_RXB0CTRL, 0x60, 0x60);
	//mcp_bit_modify(MCP_RXB0CTRL, 0x04, 0x00);
	//mcp_bit_modify(MCP_CANINTE, MCP_NO_INT, 0xFF );
	//mcp_bit_modify(MCP_CANINTE, 0x01, 0xFF );
	
	//_delay_ms(100);
	mcp_bit_modify(MCP_CANCTRL, MODE_MASK, MODE_LOOPBACK);

	//_delay_ms(100);
	
	if((mcp_read(MCP_CANSTAT)& MODE_MASK) == MODE_LOOPBACK) {
		printf("MCP2515 is in loop back mode mode!\n");
	}
	
	 if((mcp_read(MCP_CANSTAT)& MODE_MASK) == MODE_CONFIG) {
		printf("MCP2515 is in CONFIG mode!\n");
	}
}
void can_transmit(message_can message)
{
	while (mcp_read(MCP_TXB0CTRL) & (MCP_TXREQ)!= 0){}

		
	mcp_write( MCP_TXB0SIDH,(message.id >> 8));
	mcp_write( MCP_TXB0SIDL,(message.id)&0x0FF);
	mcp_write( MCP_TXB0DLC,message.length&0xF);
	for (uint8_t i = 0; i < message.length; i++)
	{
		 mcp_write( MCP_TXB0D0+i,message.data[i]);
	}
	mcp_request_send(0);

	
}
message_can can_receive(void)
{
	message_can message ={0};
		
	if (mcp_read(MCP_CANINTF) & (MCP_RX0IF))
	{
		uint8_t low = mcp_read(MCP_RXB0SIDL);
		low /= 0b100000;
		uint8_t high = mcp_read(MCP_RXB0SIDH);
		high *= 0b1000;
		message.id = high + low;
		message.length = (mcp_read(MCP_RXB0DLC)) & (0x0f);
		for (uint8_t i = 0; i < message.length; i++)
		{
			message.data[i] = mcp_read(MCP_RXB0D0 + i);
		}
		rxbuffer = 0;
		mcp_bit_modify(MCP_CANINTF, MCP_RX0IF, REMOVE_INT);


	}
	
	return message;
}
