/*
 * Joystick.c
 *
 * Created: 13.09.2016 17:01:26
 *  Author: simonep
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/delay.h>
#include <stdio.h>
#include <math.h>

/*INT0_vect()
{
	while(1)
	{
		
	}

}
*/



int joystick_analog_position(uint8_t adc_pos){

	if(adc_pos >= 129 && adc_pos <= 131) return 0;
	else
	{
		int percentage = ((adc_pos - 127)*100)/127;
		return percentage;		
	}

}
