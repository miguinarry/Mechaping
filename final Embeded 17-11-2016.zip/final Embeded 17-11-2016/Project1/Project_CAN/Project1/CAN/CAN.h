/*
 * CAN.h
 *
 * Created: 11.10.2016 16:05:38
 *  Author: simonep
 */ 


#ifndef CAN_H_
#define CAN_H_
#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include "../MCP2515/MCP2515_cmd.h"
#include "../MCP2515/MCP2515.h"

typedef struct
{
		unsigned int id;
	 	uint8_t length;
	 	uint8_t data[8];
} message_can;

void can_init(uint8_t mode);
void can_transmit(message_can message);
message_can can_receive(void);


#endif /* CAN_H_ */