/*
 * Project1.c
 *
 * Created: 30.08.2016 14:36:50
 *  Author: simonep
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/io.h>
#define F_CPU 4915200UL
#include <util/delay.h>
#include "Hardware/UART.h"
#include "oled/oled.h"
#include "oled/Menu.h"
#include "Joystick_driver/Joystick.h"
#include "MCP2515/MCP2515.h"
#include "MCP2515/MCP2515_cmd.h"
#include "SPI/SPI.h"
#include "CAN/CAN.h"
#include "SPI/SPI.h"

#define FOSC 4915200
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

#define FOSC_NODE2 15974400
#define BAUD_NODE2 9600
#define MYUBRR_NODE2 FOSC_NODE2/16/BAUD_NODE2-1

#define test_bit( reg, bit ) (reg & (1 << bit))

void EEPROM_write(unsigned int uiAddress, unsigned char ucData)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEWE))
	;
	/* Set up address and data registers */
	EEAR = uiAddress;
	EEDR = ucData;
	/* Write logical one to EEMWE */
	EECR |= (1<<EEMWE);
	/* Start eeprom write by setting EEWE */
	EECR |= (1<<EEWE);
}

unsigned char EEPROM_read(unsigned int uiAddress)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEWE))
	;
	/* Set up address register */
	EEAR = uiAddress;
	/* Start eeprom read by writing EERE */
	EECR |= (1<<EERE);
	/* Return data from data register */
	return EEDR;
}

void SRAM_test(void)
{
	volatile char *ext_ram = (char *) 0x1800; // Start address for the SRAM
	uint16_t ext_ram_size = 0x800;
	uint16_t write_errors = 0;
	uint16_t retrieval_errors = 0;
	//printf("Starting SRAM test...\n");
	// rand() stores some internal state, so calling this function in a loop will
	// yield different seeds each time (unless srand() is called before this function)
	uint16_t seed = rand();
	// Write phase: Immediately check that the correct value was stored
	srand(seed);
	for (uint16_t i = 0; i < ext_ram_size; i++)
	{
		uint8_t some_value = rand();
		ext_ram[i] = some_value;
		uint8_t retreived_value = ext_ram[i];
		if (retreived_value != some_value)
		{
			//printf("Write phase error: ext_ram[%4d] = %02X (should be %02X)\n", i, retreived_value, some_value); 
			write_errors++;
		}
	}
	// Retrieval phase: Check that no values were changed during or after the write phase
	srand(seed);
	// reset the PRNG to the state it had before the write phase
	for (uint16_t i = 0; i < ext_ram_size; i++)
	{
		uint8_t some_value = rand();
		uint8_t retreived_value = ext_ram[i];
		if (retreived_value != some_value)
		{
			//printf("Retrieval phase error: ext_ram[%4d] = %02X (should be %02X)\n", i, retreived_value, some_value); 
			retrieval_errors++;
		}
	}
	//printf("SRAM test completed with \n%4d errors in write phase and \n%4d errors in retrieval phase\n\n", write_errors, retrieval_errors);
}



int main(void)
{
	
	uint8_t line_arrow=0;
	volatile unsigned char mem_val;
	bool trash;
	bool menu_or_game;	//0 for menu, 1 for game
	uint8_t number_of_pings;
	USART_Init(MYUBRR);
	MCUCR |= (1<<SRE);
	SFIOR |=(1<<XMM2);
	DDRD = 0x10;
	oled_init();
	volatile uint8_t *adc = (uint8_t *) 0x1400;
	
	
	oled_reset();
	_delay_ms(1000);
	

	ITEM* current_menu= menu_setup();
	menu_or_game = print_menu(current_menu);	//returns false on initialization
	
	volatile uint8_t x;	
	volatile uint8_t y;
	uint8_t current_state =0;
	uint8_t previous_state = 0;
	
	
		
	message_can msg,msg_rx;
	
	msg.id = 1;
	msg.data[0] = 13;
	msg.data[3] = 0;
	msg.length = 4;
	
	can_init(MODE_NORMAL);
	
	//EEPROM_write(0x01,number_of_pings);
	mem_val = EEPROM_read(0x01);
	
		
	while (1)
	{
		
		if(menu_or_game == false){	
		
			//joystick y axis
			_delay_ms(20);
			adc [0]= 0b0101;
			_delay_us(100);
			y = adc[0];
		
			//printf("y: %d\n",y);
		
			msg.data[1]=y;
		
		
			if (joystick_analog_position(y)>80)
			{
				current_state =1;
				if (previous_state!=current_state)
				{
					previous_state=current_state;
					if (line_arrow>0)
					{
						line_arrow=line_arrow-1;
						arrow_up(line_arrow);
					}
				}
			}
		
		
			if (joystick_analog_position(y)<-80)
			{
				current_state =2;
				if (previous_state!=current_state)
				{
					previous_state=current_state;
					if (line_arrow <4)
					{
						line_arrow=line_arrow+1;
						arrow_down(line_arrow);
				
					}	
				}
			
			}
		
			//joystick x axis
			_delay_ms(20);
			adc [0]= 0b0100;
			_delay_us(100);
			x = adc[0];
			msg.data[0]=x;
			//printf("x = %d\n",x);
		
			if (joystick_analog_position(x)>80)
			{
				current_state =3;
				if (previous_state!=current_state)
				{
					previous_state=current_state;
					if (current_menu->children[line_arrow]!=NULL)
					{
						current_menu=current_menu->children[line_arrow];
						line_arrow=0; 
						menu_or_game = print_menu(current_menu);
					}
				}
			
			}
		
			if (joystick_analog_position(x)<-80)
			{
				current_state =4;
				if (previous_state!=current_state)
				{
					previous_state=current_state;
					if (current_menu->parent!=NULL)
					{
						current_menu=current_menu->parent;
						line_arrow=0;
						menu_or_game = print_menu(current_menu);
					}
				}
			}
			if (joystick_analog_position(x)<80 && joystick_analog_position(x)>-80 && joystick_analog_position(y)<80 && joystick_analog_position(y)>-80)
			{
				current_state =5;
				if (previous_state!=current_state)
				{
					previous_state=current_state;
				}
			}
		
		
			_delay_ms(100);
	
	
	
		}	//if menugame == false end
		
		else if(menu_or_game == true){
			
			msg_rx = can_receive();
			
			//joystick y axis
			_delay_ms(20);
			adc [0]= 0b0101;
			_delay_us(100);
			y = adc[0];
			//printf("y: %d\t",y);
			
			//joystick x axis
			_delay_ms(20);
			adc [0]= 0b0100;
			_delay_us(100);
			x = adc[0];
			//printf("x = %d\t",x);
			
			printf("number of pings: %d\t",msg_rx.data[0]);
			//printf("number of goals: %d\t",msg_rx.data[1]);
			printf("memory value: %d\n",mem_val);
			
			msg.data[0]=x;
			msg.data[1]=y;
			msg.data[2]=test_bit(PIND,PD5);
			
			//printf("button = %d\n",msg.data[2]);
			
				
			
			number_of_pings = msg_rx.data[0];
			
					
			//go back to menu from new game
			if(test_bit(PIND,PD4) != 0){
				current_menu = current_menu->parent;
				line_arrow=0;
				menu_or_game = print_menu(current_menu);
				mem_val = EEPROM_read(0x01);
				
				
				
				if(number_of_pings > (EEPROM_read(0x01)) ){
					printf("hello");
					EEPROM_write(0x01,number_of_pings);
				}
				
				mem_val = EEPROM_read(0x01);
				printf("%d\n", mem_val);
				msg.data[3]=1;
			}
			
			can_transmit(msg);
			msg.data[3]=0;
			_delay_ms(100);	
		}
	
	
	}
	
   

	/*
		
		//Left slider value
		adc [0]= 0b0110;
		_delay_ms(100);
		val = adc[0];
		printf(", Value left slider: %i", joystick_analog_position(val));
		
		//Right slider value
		adc [0]= 0b0111;
		_delay_ms(100);
		val = adc[0];
		printf(", Value right slider: %i \n", joystick_analog_position(val));
		*/
	

	return 0;
}