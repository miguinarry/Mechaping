/*
 * UART.h
 *
 * Created: 30.08.2016 17:40:58
 *  Author: simonep
 */ 


#ifndef UART_H_
#define UART_H_

void USART_Transmit( unsigned char data );
unsigned char USART_Receive( void );
void USART_Init( unsigned int ubrr );



#endif /* UART_H_ */