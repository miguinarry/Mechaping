/*
 * Menu.h
 *
 * Created: 04.10.2016 11:41:27
 *  Author: simonep
 */ 


#ifndef MENU_H_
#define MENU_H_

 
 typedef struct item{
	 
	 char* text[5];
	 struct item *parent;        //
	 struct item *children[5];
	 
 }ITEM;

ITEM* menu_setup( void );
bool print_menu( ITEM * menuScreen);
void arrow_up(uint8_t line_arrow);
void arrow_down(uint8_t line_arrow);

#endif /* MENU_H_ */