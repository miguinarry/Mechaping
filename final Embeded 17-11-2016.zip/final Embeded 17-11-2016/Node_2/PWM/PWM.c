/*
 * PWM.c
 *
 * Created: 25.10.2016 12:05:39
 *  Author: simonep
 */ 
#include "PWM.h"
#include <avr/io.h>
#include "../MCP/MCP2515.h"
#define F_CPU 16000000.0


void pwm_init(float ms) 
{
 // Clear OC1A on compare match
	TCCR1A |= (1 << COM1A1);
	// Set mode 14: Fast PWM, TOP(OCRA), update at bottom, tov on top

	TCCR1A |= (1 << WGM11);

	TCCR1B |= (1 << WGM12);

	TCCR1B |= (1 << WGM13);
 // Set prescaler clk/8
	(TCCR1B |= (1 << CS11));
	
	// ENABLE INTERRUPT WITH TOV
	
	ICR1 = 40000; //(1/F_PWM)/(8/F_CPU)
	pwm_set_width(ms);

	(DDRB |= (1 << DDB5));
}


void pwm_set_width(float ms) 
{
	if ((ms > 0.9) && (ms < 2.1)) 
	{
		OCR1A = ms*2000; //Output compare register
	}
}
