/*
 * solenoid.h
 *
 * Created: 08.11.2016 15:44:27
 *  Author: simonep
 */ 


#ifndef SOLENOID_H_
#define SOLENOID_H_

void solenoid_init(void);
void solenoid_ping(void);


#endif /* SOLENOID_H_ */