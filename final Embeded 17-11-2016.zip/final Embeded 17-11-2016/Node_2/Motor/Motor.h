/*
 * Motor.h
 *
 * Created: 01.11.2016 16:06:12
 *  Author: simonep
 */ 


#ifndef MOTOR_H_
#define MOTOR_H_

typedef enum motor_dir {LEFT, RIGHT} motor_direction_t;

void motor_init(void);
void motor_reset_counter(void);
int16_t motor_read_encoder(void);
void motor_set_direction(motor_direction_t dir);
void motor_set_speed(char speed);




#endif /* MOTOR_H_ */